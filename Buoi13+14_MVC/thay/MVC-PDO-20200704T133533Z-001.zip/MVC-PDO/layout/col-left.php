<nav style="padding-top: 65px;" class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">

	<ul class="nav nav-pills flex-column">
		<li class="nav-item">
			<a class="nav-link" href="index.php">Danh sách học viên</a>
		</li>
		<li class="nav-item">
			<a class="nav-link" href="index.php?page=list-member&method=add">Thêm mới</a>
		</li>
	</ul>
</nav>