<?php  
	
	include_once 'config/myConfig.php';

	class Member_m extends Connect
	{
		
		function __construct()
		{
			parent::__construct(); // Thực hiện việc kết nối CSDL khi khởi tạo đối tượng. Biến $conn luôn tồn tại
		}

		// Các hàm truy vấn với CSDL
		public function getMember(){
			$sql = "SELECT *FROM tbl_hocvien";
			return $this->pdo->query($sql);


			// $sql = "SELECT *FROM tbl_hocvien";
			// $query = mysqli_query($this->conn, $sql);
			// $result = array();

			// while ($row = mysqli_fetch_array($query)) {
			// 	$result[] = $row;
			// }

			// return $result;
		}

	}

?>