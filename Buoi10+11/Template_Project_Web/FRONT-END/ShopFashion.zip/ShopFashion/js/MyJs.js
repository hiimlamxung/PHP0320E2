$(document).ready(function(){
	$(".alert").delay(3000).slideUp();
})