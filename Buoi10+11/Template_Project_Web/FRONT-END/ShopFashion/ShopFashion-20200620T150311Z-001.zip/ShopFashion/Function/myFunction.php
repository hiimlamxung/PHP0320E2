<?php  
	function getPro_Hot(){
		global $conn;

		$sql = "SELECT *FROM tbl_product WHERE stt = 2";
		$query = mysqli_query($conn, $sql);
		$result = array();

		while ($row = mysqli_fetch_array($query)) {
			$result[] = $row;
		}

		return $result; 
	}

	function getId_product($id){
		global $conn;

		$sql = "SELECT *FROM tbl_product WHERE id = $id";
		$query = mysqli_query($conn, $sql);
		return mysqli_fetch_array($query);
	}

?>