<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('infomation', function () {
    return view('index');
});

Route::get('info',function(){
	echo "xin chao cac ban !";
});

Route::get('info/myname',function(){
	return "Cam on ban !";
});

Route::match(['get','post'],'data',function(){
	echo "Route match co 2 phuog thuc post get";
});

Route::resource('user','UserController');

Route::group(['prefix'=>'admin'],function(){
	Route::get('news', function() {
	    echo "Day la trang tin tuc";
	});

	Route::get('member', function() {
	    echo "Day la trang thanh vien";
	});
});

Route::get('get-name/{name}', function($name) {
    echo "Ten cua toi la ".$name;
});

Route::get('get-name/{name}/{age}', function($name,$age) {
    return view('index', ['name' => $name],['age' => $age]);
});

Route::get('sum/{number1}/{number2}', function($number1,$number2) {
    echo "Tong = ".$sum=$number1+$number2;
});

Route::get('user/info/member', function() {
    echo " Thong tin thanh vien lop PHP0320E2";
})->name('php0320');

// //Chuyển hướng người dùng đến trang user/info/member khi truy cập trang info (giốg chức năng header)
// Route::get('info',function(){
// 	return redirect(route('php0320'));
// });