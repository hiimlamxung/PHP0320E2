<div class="row footer">
				<div class="col-md-12 text-center">
					Hệ thống học viên IT Plus <br>
					Copyright © 2011 All Rights Reserved. Phát triển bởi ITPlus Academy
				</div>
			</div>