<h4>DANH SÁCH HỌC VIÊN IT-PLUS</h4>
<div class="table-responsive">
	<table class="table table-hover">
		<thead>
			<tr>
				<th>STT</th>
				<th>Name</th>
				<th>Phone</th>
				<th>Email</th>
				<th>Addres</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>Trịnh Khắc Tùng</td>
				<td>0373888999</td>
				<td>khactung7@gmail.com</td>
				<td>Thanh Hóa</td>
				<td>
					<a href="index.php?page=edit-member">
						<button class="btn btn-primary">Sửa</button>
					</a>
					<a href="#">
						<button class="btn btn-danger">Xóa</button>
					</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>