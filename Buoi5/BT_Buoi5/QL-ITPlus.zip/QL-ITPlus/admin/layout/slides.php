<div class="col-md-12">
					<img src="http://itplus-academy.edu.vn/upload/e0299984838d38ecac3805d4d6661829/files/banner%20sao%20khue-03.jpg" alt="IT-Plus" class="responsive" style="width: 100%;" />
				</div>